import os

try:
    from InquirerPy import inquirer as iq
except:
    print("\033[31mCannot find inquirerpy. The package checker was unable to install it.\nRestart the program to re-run the package checker or install inquirerpy manually.\033[00m")

try:
    import imageio_ffmpeg as ff
    ff_path = ff.get_ffmpeg_exe()
except:
    print("\033[31mCannot find ffmpeg. The package checker was unable to install it.\nRestart the program to re-run the package checker or install ffmpeg manually.\033[00m")

try:
    from yt_dlp import YoutubeDL as ytdl
    youtubedl = ytdl({})
except:
    print("\033[31mCannot find yt-dlp. The package checker was unable to install it.\nRestart the program to re-run the package checker or install yt-dlp manually.\033[00m")



red = "\033[31m"
grn = "\033[92m"
cyn = "\033[96m"
ong = "\033[33m"
bld = "\033[1m"
neg = "\033[7m"
rst = "\033[00m"

download_link = ""
download_options = {}



def clear():    #clear teminal
    os.system("cls" if os.name == "nt" else "clear")

def is_downloadable(url):
    try:
        print(f"{grn}{bld}\n\n[ Extracting video(s) information... ]{rst}")
        info = youtubedl.extract_info(url, download=False)
        clear()

        print(f"{grn}{bld}[ Video extracted from link! ]\n{rst}")
        print(f"{cyn} Video title - {ong}{neg} {info.get("title")} {rst} \n{cyn} Uploaded by - {ong}{neg} {info.get("uploader")} {rst}\n")
        input(f"{red}{bld}[ Press {rst}{bld}[ENTER]{red}{bld} to start downloading ]")
        return True
    except:
        print(f"{red}{bld}\n\n[ Failed to extract (blocked by yt) ]\n")
        return False



def video_download():

    print(f"{ong}{neg} [ Video/Playlist needs to be either public or unlisted to be downloaded ] {rst}")
    print(f"{ong}{neg} [ Press right mouse button to paste copied link ] {rst}")
    download_link = input(f"{grn}{bld}[ Enter a valid youtube video/playlist link ] > {rst}")

    print(f"\n\n\n{ong}{neg}[ Select a download format ]{rst}")
    quality = iq.select(
        message="",
        show_cursor=False,
        qmark="",
        choices=[
            {"name": "[ Highest quality ] (.webm)", "value": "bestvideo+bestaudio/best"},
            {"name": "[ Lowest quality ] (.mp4)", "value": "worstvideo+bestaudio/worst"},
            {"name": "[ Audio only ] (.m4a)", "value": "bestaudio[ext=m4a]"}
        ]
    ).execute()

    download_options = {
        'ffmpeg_location': ff_path,
        'outtmpl': './downloads/%(title)s.%(ext)s',
        'format': quality
    }

    if is_downloadable(download_link):

        clear()

        print(f"{grn}{bld}[ Downloading file(s)... ]{rst}\n")

        try:
            ytdl(download_options).download([download_link])
            print(f"{grn}{bld}\n[ Downloaded successfully! ]{rst}")
            input(f"{grn}{bld}[ File(s) saved in \"YFetch/downloads\" folder ]{rst}")
        except:
            input(f"{red}{bld}\n[ Failed to download (blocked by yt) ]{rst}")

    else:
        input(f"{red}{bld}[ Failed to download (unknown) ]{rst}")