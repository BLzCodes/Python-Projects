import os
import sys
import subprocess

def package_check(package=None):    #package installer+updater
    print(f"\033[92m[ Checking and updating {package} ]\033[00m")
    subprocess.run([sys.executable, "-m", "pip", "install", package])
    subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", package])
    print("\033[92m[ Done ]\033[00m\n")

package_check("yt-dlp")
package_check("imageio-ffmpeg")
package_check("InquirerPy")

try:
    from InquirerPy import inquirer as iq
except:
    print("\033[31mCannot find inquirerpy. The package checker was unable to install it for some reason.\nRestart the program to re-run the package checker or install inquirerpy manually.\033[00m")

from loader import video_download



red = "\033[31m"
bld = "\033[1m"
rst = "\033[00m"

main_menu_logo = f"""
{red}██╗░░░██╗{rst}███████╗███████╗████████╗░█████╗░██╗░░██╗
{red}╚██╗░██╔╝{rst}██╔════╝██╔════╝╚══██╔══╝██╔══██╗██║░░██║
{red}░╚████╔╝░{rst}█████╗░░█████╗░░░░░██║░░░██║░░╚═╝███████║
{red}░░╚██╔╝░░{rst}██╔══╝░░██╔══╝░░░░░██║░░░██║░░██╗██╔══██║
{red}░░░██║░░░{rst}██║░░░░░███████╗░░░██║░░░╚█████╔╝██║░░██║
{red}░░░╚═╝░░░{rst}╚═╝░░░░░╚══════╝░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝\n\n\n"""

inst = f"{red}    Use {rst}{bld}[↑/↓]{red} to navigate & {rst}{bld}[ENTER]{red} to select     {rst}\n"



def clear():    #clear teminal
    os.system("cls" if os.name == "nt" else "clear")

def quit():     #quit application
    sys.exit()



def main():     #main menu
    while True:

        clear()

        print(main_menu_logo)
        print(inst)

        choice = iq.select(
            message="",
            show_cursor=False,
            qmark="",
            choices=[
                {"name": "Download a Video/Playlist", "value": 1},
                {"name": "Quit", "value": 2}
            ]
        ).execute()

        clear()

        if choice == 1:
            video_download()
        elif choice == 2:
            quit()

main()